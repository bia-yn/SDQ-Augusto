import "./styles.css";
import "./responsivo.css";
import Menu from "./componentes/Menu";
import Quadrado from "./componentes/Quadrado";
import ComoFunc from "./componentes/ComoFunc";
import TiposCoisas from "./componentes/TiposCoisas";
import MenuF from "./componentes/MenuF";
import Login from "./componentes/Login";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import Cadastro from "./componentes/Cadastro";
export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Quadrado/>}/>
        <Route path="/Cadastro" element={<Cadastro/>}/>
        <Route path="/Login" element={<Login/>}/>
        <Route path="/ComoFunc" element={<ComoFunc/>}/>
      </Routes>
    </BrowserRouter>
  );
}
