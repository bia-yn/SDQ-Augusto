import React, { useState } from "react";
import fundologin from "../img/fundologin.png";
import Menu from "./Menu";
import axios from "axios";
import { text } from "stream/consumers";
import { Navigate } from "react-router-dom";
function Login() {
  const [email, setEmail] = useState("");
  const [senha, setSenha] = useState("");

  const Login = () => {
    axios.post("http://127.0.0.1:5000/users/login", {
      email: email,
      senha: senha
    })
    .then((value)=>{
      console.log(value);

    })
    .catch((e) => {
      console.log(e)
    });
  }
  return (
    <>
    <Menu/>
      <div className="loginfundo" background-image="url(../img/farmaceutica.png)">
        <a href="#fazerlogin">
          <h1 id="fazerlogin">Fazer login</h1>
        </a>
        <p id="acesso">para ter acesso com mais facilidade</p>
        <div id="loginquadrado">
          <form>
            <div id="email">
              <label htmlFor="email">E-mail: </label>
              <input type="email" id="email" required value={email} onChange={(text) => setEmail(text.target.value)} />
            </div>

            <div id="senha">
              <label htmlFor="senha">Senha: </label>
              <input type="password" id="senha" required value={senha} onChange={(text) =>setSenha(text.target.value)} />
            </div>
              <div style={{padding: 5}}/>
                <input type="submit" className="butaoP" onClick={Login} name="FAZER LOGIN" />

                <button name="Esqueci a senha" id="esqueci_senha">
                  Esqueci a senha
                </button>
            
          </form>
        </div>
      </div>
    </>
  );
}

export default Login;
