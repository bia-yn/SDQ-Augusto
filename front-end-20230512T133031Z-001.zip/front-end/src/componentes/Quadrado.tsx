import React from "react";
import Cadastro from "./Cadastro";
import Menu from "./Menu";
import { Link } from "react-router-dom";

function Quadrado() {
  return (
    <>
      <Menu/>
      <div id="farmaceutica">
        <div id="quadrado1">
          <h1 id="saude">Saúde quando você mais precisa.</h1>
          <div className="butoesPjuntos">
                <Link className="butaoP" id="login" to="/Login">Login</Link>
                <Link className="butaoP" id="login" to="/Cadastro">Cadastro</Link>
          </div>
        </div>
      </div>
    </>
  );
}

export default Quadrado;
