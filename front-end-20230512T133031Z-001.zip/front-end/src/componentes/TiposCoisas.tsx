import medico from "../img/medico.png";
import remedios from "../img/remedios.png";
import caixadeconversa from "../img/caixadeconversa.png";

function TiposCoisas() {
  return (
    <>
      <h1 id="certificados">Certificados.Eficazes.Humanos</h1>

      <div>
        <img className="tiposfts" src={medico} alt="medico" />
        <img className="tiposfts" src={remedios} alt="remedios" />
        <img className="tiposfts" src={caixadeconversa} alt="conversa" />
      </div>

      <div id="irTodos">
        <div className="ir">
          <h3>AGENDA MÉDICA</h3>
          <p>Agendar sua consulta médica.</p>
          <button className="butaoP">
            CONSULTAR
          </button>
        </div>

        <div className="ir">
          <h3>CONSULTAR REMÉDIOS</h3>
          <p>Consultar remédios disponiveis.</p>
          <button className="butaoP">
            CONSULTAR
          </button>
        </div>

        <div className="ir">
          <h3>FALE CONOSCO</h3>
          <p>Tire suas dúvidas.</p>
          <button className="butaoP">
            {" "}
            FALE CONOSCO
          </button>
        </div>
      </div>
    </>
  );
}

export default TiposCoisas;
