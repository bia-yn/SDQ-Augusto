import React from "react";
import telefone from "../img/telefone.png";
import conversa from "../img/conversa.png";
import caderno from "../img/caderno.png";
import calendario from "../img/calendario.png";

function ComoFunc() {
  return (
    <>
      <div className="funciona">
        <a href="#comofunciona" id="linkcomof">
          <h1 id="comofunciona"> Como funciona</h1>
        </a>
        <img id="telefone" src={telefone} alt="telefone" />
      </div>

      <img className="fototipos" src={conversa} alt="caixaconversa" />
      <div className="funcionatipos">
        <h3 id="fale">FALE CONOSCO</h3>
        <p className="funcionaP">Tire suas duvidas</p>
      </div>

      <img className="fototipos" src={caderno} alt="remedios" />
      <div className="funcionatipos">
        <h3 id="consulte">CONSULTE OS REMÉDIOS</h3>
        <p className="funcionaP">quais remédios estão disponiveis</p>
      </div>

      <img className="fototipos" src={calendario} alt="calendario" />
      <div className="funcionatipos">
        <h3 id="agendar">AGENDAR CONSULTAS</h3>
        <p className="funcionaP">Sabendo o que é melhor para você e para nós</p>
      </div>
    </>
  );
}

export default ComoFunc;
