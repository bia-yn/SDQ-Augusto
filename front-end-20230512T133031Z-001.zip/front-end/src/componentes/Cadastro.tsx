import React, { useState } from "react";
import fundologin from "../img/fundologin.png";
import Menu from "./Menu";
import axios from "axios";
import { text } from "stream/consumers";
import { redirect } from "react-router-dom";
function Cadastro() {
  const [email, setEmail] = useState("");
  const [nome, setNome] = useState("");
  const [senha, setSenha] = useState("");
  const [telefone, setTelefone] = useState("");
  const Cadastro = () => {
    axios.post("http://127.0.0.1:5000/users",{
      nome: nome,
      email: email,
      senha: senha,
      telefone: telefone
      
    })
    .then((query) => {
      console.log(query)
      
    })
    .catch((e) =>{
      console.log(e)
    })
  }

  return (
    <>
    <Menu/>
      <div className="loginfundo" background-image="url(../img/farmaceutica.png)">
        <a href="#fazerlogin">
          <h1 id="fazerlogin">Cadastrar</h1>
        </a>
        <p id="acesso">para ter acesso com mais facilidade</p>
        <div id="loginquadrado">
          <form>
            <div id="nome">
              <label htmlFor="nome">Nome:  </label>
              <input type="text" id="nome" value={nome} required onChange={(text)=>setNome(text.target.value)} />
            </div>
            <div id="nome">
              <label htmlFor="nome">Email:  </label>
              <input type="email" id="nome" value={email} required onChange={(text)=>setEmail(text.target.value)} />
            </div>
            <div id="email">
              <label htmlFor="email">Senha: </label>
              <input type="password" id="email" required value={senha} onChange={(text)=>setSenha(text.target.value)}/>
            </div>

            <div id="senha">
              <label htmlFor="senha" style={{fontSize:16}}>Telefone:</label>
              <input id="senha" required value={telefone} onChange={(text)=>setTelefone(text.target.value)} />
            </div>

            <input type="submit" className="butaoP" name="FAZER CADASTRO" onClick={Cadastro} />
          </form>
        </div>
      </div>
    </>
  );

}

export default Cadastro;
